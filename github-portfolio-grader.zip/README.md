
# 🚀 GitRecruiter AI - Portfolio Grader

Built for the **UnsaidTalks Hackathon 2026**. GitRecruiter AI is a high-performance tool designed to help students and developers bridge the gap between "coding" and "hiring" by providing objective, AI-driven portfolio audits.

## ✨ Key Features
- **Hireability Scoring:** 0-100 score based on 6 core hiring dimensions (Documentation, Impact, etc.).
- **Recruiter Monologue:** AI-generated summary of what a FAANG senior recruiter thinks of your profile.
- **Actionable Roadmap:** Specific tasks to increase your score, ranked by priority and impact.
- **Red Flags & Strengths:** Instant identification of gaps that might be hurting your job search.

## 🛠️ Tech Stack
- **Framework:** React 19 + TypeScript
- **AI:** Google Gemini 3 Pro (via @google/genai)
- **Styling:** Tailwind CSS (Glassmorphism & Cyber-Recruiter UI)
- **Charts:** Recharts
- **Deployment:** Vercel

## 🚀 One-Click Deployment
1. Push this code to a new GitHub Repository.
2. Connect the repository to **Vercel**.
3. Add your `API_KEY` from [Google AI Studio](https://aistudio.google.com/) to the Vercel Environment Variables.
4. **Deploy!**

## 📝 Configuration
To increase your GitHub API rate limit for heavy usage, you can optionally add a `GITHUB_TOKEN` to your environment variables.

---
*Empowering the next generation of developers to stand out in the 2026 market.*
